import React, { useState } from "react";
import { PieChart, Pie, Cell, Sector } from "recharts";
import Succeeded from "./Succeeded";
import './PieChart2.css';

const initialData = [
  { name: "Part 1",  value:12.5},
  { name: "Part 2",  value: 12.5},
  { name: "Part 3", value: 12.5},
  { name: "Part 4", value: 12.5},
  { name: "Part 5",  value: 12.5},
  { name: "Part 6",  value: 12.5},
  { name: "Part 7", value: 12.5},
  { name: "Part 8", value: 12.5 },
];
      
const COLORS = [
  "rgba(255,0,0,1)",
  "rgba(255,0,0,0.8)",
  "rgba(255,0,0,0.6)",
  "rgba(255,0,0,0.4)",
  "rgba(255,0,0,0.2)",
  "rgba(255,0,0,0.1)",
];

const COLORSDATA=[
  "rgb(255,0,0)",
  "rgb(255, 128, 0)",
  "rgb(255, 255, 0)",
  "rgb(0, 255, 0)",
  "rgb(0, 255, 255)	",
  "rgb(255, 0, 128)",
  "	rgb(0, 0, 255)",
  "rgb(128, 0, 255)	"
]
const PieChart2 = () => {
  const [data, setData] = useState(initialData);
  const [activeIndex, setActiveIndex] = useState(null);
  const[part,setPart]=useState(null);

  

  // const onPieClick = (clickedData, index) => {
  //   console.log("ind",index)
  //   if (activeIndex === index) {
  //     setActiveIndex(null);
  //   } else {
  //     const originalValue = data[index].value;
  //     const newValue = originalValue / 4;
 

  //     const newData = data.map((item, i) => {
  //       // debugger;
        
  //       // if (i === index) {

  //         return { ...item, value: newValue };
  //       // } else if (item.value !== newValue) {
  //       //   return { ...item, value: newValue };
  //       // }
  //       return item;
  //     });
  //     console.log(newData)
  //     setActiveIndex(index);
  //     setData(newData);
  //   }
  // };


  
  // הפונקציה לשינוי צבע במערך
  const changeColorAtIndex=(index) =>{
    // פרצ' את הצבע למערך באמצעות האינדקס והשנה את הערך של ה- alpha
    var color = COLORSDATA[index];
    var newAlpha=0;
    var parts = color.match(/(\d+(?:\.\d+)?)/g);
   
      var r = parts[0];
      var g = parts[1];
      var b = parts[2];
      for(var i=0;i<COLORS.length;i++){
        COLORS[i] = `rgba(${r},${g},${b},${newAlpha+=0.15})`;
      
    }
  
  }

  const onPieClick = (clickedData, index) => {
    
  
    changeColorAtIndex(index);
    // Divide the clicked part into four
    const originalValue = data[index].value;
    const newValue = originalValue / 6;
  
    const newData = data.map((item, i) => {
      // if (i === index) {
        return { ...item, value: newValue };
      // }
      // return item;
    });

      // const newData = data.map((item, i) => {
      //   if (i === index) {
      //     return { ...item, value: originalValue - (3 * newValue) };
      //   } else if (item.value !== newValue) {
      //     return { ...item, value: newValue };  
      //   }
      //   return item;
      // });
    
      setActiveIndex(index); 
    // Update the data with the new values
    setData(newData);
     
  };
  


const sectors=4;
const [start,setStart]=useState(0);
const [end,setEnd]=useState(sectors);
  return (

  <div>

    <PieChart className="recharts-wrapper" width={4000} height={4000}>
      <Pie  
      // cx="50%"
      // cy="80%"
      // outerRadius="100%"
     
        activeIndex={activeIndex}
        activeShape={({ cx, cy, innerRadius, outerRadius, startAngle, endAngle }) => (
          <g>
            {/* <text x={cx} y={cy} dy={8} textAnchor="middle" fill="black">
          מילים יפות
            </text> */}

            {
               [...Array(sectors)].map((index) => (
                <Sector
                cx={cx}
                cy={cy}
                innerRadius={innerRadius}
                outerRadius={outerRadius}
                startAngle={start}
                endAngle={(endAngle - startAngle) / (sectors * (index + 1)) + startAngle}
                fill={COLORS[0]} 
                onClick={()=>{setPart(index)}}   
              >  <text x={cx} y={cy} dy={-15} textAnchor="middle" fill="black">
                    מילים יפות
                </text>
             </Sector>
                )
                
            )
          }
           
           
            {/* <Sector
              cx={cx}
              cy={cy}
              startAngle={(endAngle - startAngle) / 6 }
              innerRadius={innerRadius}
              outerRadius={outerRadius}+ startAngle}
              endAngle={(endAngle - startAngle) / 3 + startAngle}//---  /6*2
              fill={COLORS[( 1) % COLORS.length]}
              onClick={()=>{setPart(1)}}
            /> 
            */}
            <Sector
              cx={cx}
              cy={cy}
              innerRadius={innerRadius}
              outerRadius={outerRadius}
              startAngle={(endAngle - startAngle) / 3 + startAngle}
              endAngle={(endAngle - startAngle) /2 + startAngle}//    /6*3
              fill={COLORS[( 2) % COLORS.length]}
              onClick={()=>{setPart(2)}}
            />
            <Sector
              cx={cx}
              cy={cy}
              innerRadius={innerRadius}
              outerRadius={outerRadius}
              startAngle={(endAngle - startAngle) /2 + startAngle}
              endAngle={(endAngle - startAngle) *2/3 + startAngle}//    /6*4
              fill={COLORS[( 3) % COLORS.length]}
              onClick={()=>{setPart(3)}}
            />
            <Sector
              cx={cx}
              cy={cy}
              innerRadius={innerRadius}
              outerRadius={outerRadius}
              startAngle={(endAngle - startAngle) *2/3 + startAngle}
              endAngle={(endAngle - startAngle) *5/6 + startAngle}
              fill={COLORS[( 4) % COLORS.length]}
              onClick={()=>{setPart(4)}}
            />
            <Sector
              cx={cx}
              cy={cy}
              innerRadius={innerRadius}
              outerRadius={outerRadius}
              startAngle={(endAngle - startAngle)  *5/6  + startAngle}
              endAngle={endAngle}
              fill={COLORS[( 5) % COLORS.length]}
              onClick={()=>{setPart(5)}}
            />
          </g>
        )}
        data={data}
        dataKey="value"
        cx={200}
        cy={200}
        outerRadius={200}
        fill="#8884d8"
        onClick={(clickedData, index) => onPieClick(clickedData, index)}
      >
        {data.map((entry, index) => (
          <Cell key={`cell-${index}`} fill={COLORSDATA[index % COLORSDATA.length] } />
        ))}
      </Pie>
    </PieChart>
   {console.log("part=",part)}
    {part!==null && <Succeeded part={part}></Succeeded>}
    {/* {part===1 && <Succeeded part={2}/>}
    {part===2 && <Succeeded part={3}/>}
    {part===3 && <Succeeded part={4}/>}
    {part===4 && <Succeeded part={5}/>}
    {part===5 && <Succeeded part={6}/>} */}
    
    </div>
  );
};



export default PieChart2;