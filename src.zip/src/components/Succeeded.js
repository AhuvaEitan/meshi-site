import React, { useState } from "react";

function Succeeded({part}){
    return(
       <h1>SUCCEED! {part}</h1>
    );
}

export default Succeeded;