import React from "react";
import PieChart2 from "./components/PieChart2";
function App() {
    return (
      <div className="App">
        <h1>Meshi</h1>
       <PieChart2></PieChart2>
      </div>
    );
  }
  
  export default App;
